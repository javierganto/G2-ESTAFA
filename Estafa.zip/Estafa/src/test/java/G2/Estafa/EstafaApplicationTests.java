package G2.Estafa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstafaApplicationTests {

	@Test
	void contextLoads() {
	}

}
