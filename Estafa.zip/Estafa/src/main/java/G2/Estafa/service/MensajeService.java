package G2.Estafa.service;

public class MensajeService {

}
