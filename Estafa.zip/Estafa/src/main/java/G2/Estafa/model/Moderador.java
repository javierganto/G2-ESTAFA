package G2.Estafa.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
public class Moderador extends Usuario{
	@OneToMany (mappedBy = "moderador")
	List<Mensaje> moderadormensajes;
	boolean eliminar = false;
	boolean banear = false;
	public boolean getEliminarMensaje() {
		return eliminar;
	}
	public void setEliminarMensaje(boolean vistobueno) {
		eliminar = vistobueno;
	}
	public boolean getBanear() {
		return banear;
	}
	public void setBanear(boolean castigado) {
		banear = castigado;
	}
}
