package G2.Estafa.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import G2.Estafa.model.Usuario;
import G2.Estafa.service.UsuarioService;

@Controller
public class UsuarioController {
	
	@Autowired
	UsuarioService usuarioservice;
	
	@RequestMapping("/usuarios")
	public String listadousuarios(Model model) {
		List<Usuario> usuarios = usuarioservice.getAll();
		
		model.addAttribute("ListaUsuarios", usuarios);
		
		return "usuarios/index";
	}
	@RequestMapping("/usuarios/add")
	public String addusuarios(Model model) {
		return "usuarios/add";
	}
	@RequestMapping("/usuarios/edit/{nick}")
	public String editusuarios(Model model) {
		return "usuarios/edit";
	}
	@RequestMapping("/usuarios/delete/{nick}")
	public String deleteUsuarios() {
		return "redirect:/usuarios";
	}

}
