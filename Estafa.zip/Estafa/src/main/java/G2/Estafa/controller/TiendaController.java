package G2.Estafa.controller;

public class TiendaController {

}
