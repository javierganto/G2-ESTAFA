package G2.Estafa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstafaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstafaApplication.class, args);
	}

}
