package G2.Estafa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import G2.Estafa.model.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, String>{

}
