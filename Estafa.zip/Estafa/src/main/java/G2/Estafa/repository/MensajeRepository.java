package G2.Estafa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import G2.Estafa.model.Mensaje;





public interface MensajeRepository extends JpaRepository<Mensaje, String>{

	

}
