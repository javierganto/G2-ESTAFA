package G2.Estafa.repository;

public interface ModeradorRepository {

}
