package G2.Estafa.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
public class Moderador extends Usuario{
	@OneToMany (mappedBy = "moderador")
	List<Mensaje> moderadormensajes;
	Mensaje mensajes;
	boolean eliminar = false;
	boolean banear = false;
	public boolean getEliminarMensaje() {
		return !mensajes.isValidez() && eliminar && moderadormensajes.add(mensajes);
	}
	public void setEliminarMensaje(boolean vistobueno) {
		eliminar = vistobueno;
	}
	public boolean getBanear() {
		return banear && !mensajes.isValidez() && moderadormensajes.add(mensajes);
	}
	public void setBanear(boolean castigado) {
		banear = castigado;
	}
}
